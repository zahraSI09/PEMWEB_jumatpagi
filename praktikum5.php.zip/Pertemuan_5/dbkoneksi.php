<?php
// 1) Variable untuk koneksi database
$host = "localhost";
$dbname = "dbhospital";
$username = "root";
$password = "";
$charset = "utf8mb4";

// 2) Membuat DSN dan opsi akses database
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
$opt = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    // 3) Membuat objek koneksi PDO
    $dbh = new PDO($dsn, $username, $password, $opt);
} catch (PDOException $e) {
    // 4) Menampilkan pesan error jika koneksi gagal
    echo "Koneksi database gagal: " . $e->getMessage();
    exit;
}
?>
