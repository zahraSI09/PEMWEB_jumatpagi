<?php
$title = "Home - Rifa";
require_once './template/top.php';
?>

<!-- Sidebar -->
<?php require_once './template/sidebar.php'; ?>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <?php require_once './template/topbar.php'; ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid p-0">

            <!-- Welcome Section dengan Gradasi dan Tengah -->
            <div class="d-flex justify-content-center align-items-center" style="background: linear-gradient(to right, #4e73df, rgb(217, 154, 236)); color: white; height: 100vh;">
                <div class="text-center">
                    <h1 class="display-4 font-weight-bold">👋 Welcome to My Web</h1>
                    <p class="lead mb-0">Sistem Informasi | Zahra Nauroh Rahmani | 0110124099</p>
                </div>
            </div>

        </div>
        <!-- End of Container Fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <?php require_once './template/footer.php'; ?>
    <!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Scripts -->
<?php require_once './template/bottom.php'; ?>
