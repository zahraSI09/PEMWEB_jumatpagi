<?php
require './dbkoneksi.php';

if (isset($_POST['submit'])) {
    // Tangkap data dari form
    $nama = $_POST['nama'];
    $kec_id = $_POST['kec_id'];

    switch ($_POST['submit']) {
        case 'Simpan':
            // Proses insert ke database
            try {
                $sql = "INSERT INTO kelurahan (nama, kec_id) VALUES (?, ?)";
                $stmt = $dbh->prepare($sql);
                $stmt->execute([$nama, $kec_id]);

                // Redirect ke halaman list setelah insert
                header("Location: list-kelurahan.php");
                exit();
            } catch (\Throwable $e) {
                echo "Error while inserting data kelurahan: " . $e->getMessage();
            }
            break;

        case 'Ubah':
            // Proses update data
            $id = $_POST['id'];
            try {
                $sql = "UPDATE kelurahan SET nama=?, kec_id=? WHERE id=?";
                $stmt = $dbh->prepare($sql);
                $stmt->execute([$nama, $kec_id, $id]);

                // Redirect ke halaman list setelah update
                header("Location: list-kelurahan.php");
                exit();
            } catch (\Throwable $e) {
                echo "Error while updating data kelurahan: " . $e->getMessage();
            }
            break;

        case 'Hapus':
            // Proses delete data
            $id = $_POST['id'];
            try {
                $sql = "DELETE FROM kelurahan WHERE id=?";
                $stmt = $dbh->prepare($sql);
                $stmt->execute([$id]);

                // Redirect ke halaman list setelah delete
                header("Location: list-kelurahan.php");
                exit();
            } catch (\Throwable $e) {
                echo "Error while deleting data kelurahan: " . $e->getMessage();
            }
            break;

        default:
            echo "Tidak ada aksi yang ditentukan!";
            break;
    }
}
?>
