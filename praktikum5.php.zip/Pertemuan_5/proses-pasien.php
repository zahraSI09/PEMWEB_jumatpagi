<?php
require './dbkoneksi.php';

if (isset($_POST['submit'])) {
    // Tangkap data dari form
    $kode = $_POST['kode'];
    $nama = $_POST['nama'];
    $tmp_lahir = $_POST['tmp_lahir'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $kelurahan_id = $_POST['kelurahan_id'];

    // Validasi input
    if (empty($kode) || empty($nama) || empty($tmp_lahir) || empty($tgl_lahir) || empty($gender) || empty($email) || empty($alamat) || empty($kelurahan_id)) {
        echo "Semua kolom harus diisi!";
        exit;
    }

    // Validasi email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Email tidak valid!";
        exit;
    }

    // Validasi tanggal
    $date_format = 'Y-m-d'; // Format yang diharapkan
    $d = DateTime::createFromFormat($date_format, $tgl_lahir);
    if (!$d || $d->format($date_format) != $tgl_lahir) {
        echo "Tanggal lahir tidak valid!";
        exit;
    }

    try {
        // Query untuk insert data
        $sql = "INSERT INTO Pasien (nama, kode, tmp_lahir, tgl_lahir, gender, email, alamat, kelurahan_id) 
                VALUES (?,?,?,?,?,?,?,?)";
        $stmt = $dbh->prepare($sql);
        $stmt->execute([$nama, $kode, $tmp_lahir, $tgl_lahir, $gender, $email, $alamat, $kelurahan_id]);

        // Redirect ke halaman list pasien setelah berhasil
        header("Location: list-pasien.php");
        exit();  // Pastikan script berhenti setelah redirect
    } catch (\Throwable $e) {
        // Jika ada error, tampilkan pesan yang lebih ramah
        echo "Terjadi kesalahan saat menyimpan data pasien: " . $e->getMessage();
    }
}
