<?php
$title = "Home - Zahra";

require_once './template/top.php';
?>

<!-- Sidebar -->
<?php
require_once './template/sidebar.php';
?>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <?php
        require_once './template/topbar.php';
        ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <!-- Welcome Section dengan Gradasi dan Tengah -->
            <div class="d-flex justify-content-center align-items-center" style="background: linear-gradient(to right, #4e73df,rgb(217, 154, 236)); color: white; height: 100vh;">
                <div class="text-center">
                    <h1 class="display-4 font-weight-bold">👋 Welcome to My Web</h1>
                    <p class="lead mb-0">Sistem Informasi - Zahra Nauroh Rahmani - 0110124099</p>
                </div>
            </div>


            
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <?php
        require_once './template/footer.php';
        ?>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    <?php
    require_once './template/bottom.php';
    ?>